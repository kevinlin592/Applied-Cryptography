The POCO and OpenSSL are not included because of their size (4.3gb and 120mb respectively). 
If you want to compile on your own computer, you will have to acquire these libraries.
The release executable with the proper libraries can be found in the accompanying zip file.